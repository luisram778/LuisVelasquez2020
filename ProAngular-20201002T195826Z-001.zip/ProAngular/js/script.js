var P = angular.module("P",[])
P.controller("Lobo",function($scope){
	$scope.tiempo = function(){
		 $scope.t = parseInt(prompt("Ingrese los dias que se quedo"))
		 $scope.pago = parseInt(prompt("Ingrese el precio por noche"))
		 $scope.total = $scope.t*$scope.pago;
		swal("El cliente debe pagar Q"+$scope.total);
	}
	$scope.area =function(){
		$scope. m1 = parseInt(prompt("Ingrese la medida"))
		$scope. resultado = $scope.m1*$scope.m1;
		swal("Este es el area de tu cuadrado ="+$scope.resultado)
	}
	$scope.Ahorro = function(){
		$scope.ahorro = 3000*0.05;
		$scope. mes = $scope.ahorro*4;
		$scope. at = $scope.mes*12;
		swal("El ahorro de esta persona es Q"+$scope.at)
	}
	$scope.X = function(){
		$scope.cant = parseInt(prompt("Ingrese un dato"));
		swal("El numero X es: "+$scope.cant);
	}
	$scope.Formulas = function(){
		$scope. vel = parseInt(prompt("Ingrese velocidad"))
		$scope. tiem = parseInt(prompt("Ingrese tiempo"))
		$scope.dist = $scope.vel*$scope.tiem;
		swal("La Distancia es de "+$scope.dist+"m/s2");
	}
})