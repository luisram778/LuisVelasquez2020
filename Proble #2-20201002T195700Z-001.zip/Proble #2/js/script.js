function M(){
	var C1 = parseInt(prompt("ingrese 1er cantidad"));
	var C2 = parseInt(prompt("ingrese 2do cantidad"));
	if (C1>C2) {
		swal("La 1ra cantidad es la mayor");
	}else{
		swal("La 2da cantidad es la mayor");
	}
}
M();