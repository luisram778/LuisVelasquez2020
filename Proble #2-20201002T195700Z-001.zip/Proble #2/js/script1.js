function L(){
	var cl = parseInt(prompt("ingrese cantidad de lapices"));
	var rl = cl*0.85;
	var rl2 = cl*0.90;
	if (cl>=100 ) {
		swal("El precio es de"+ rl +"centavos");
	}else{
		swal("El precio es de"+ rl2 +"centavos");
	}
}
L();