function S(){
	var h = parseInt(prompt("Ingrese horas trabajadas"));
	var ph = parseInt(prompt("Ingrese precio por hora"));
	var d = h*2;
	var th = h*ph;
	if (h>=40) {
		swal("El sueldo a pagar es de"+d+ph);
	}else{
		swal("El sueldo a pagar es de"+th);
	}
}
S();