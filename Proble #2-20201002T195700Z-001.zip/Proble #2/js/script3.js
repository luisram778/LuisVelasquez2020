function G(){
	var F = parseInt(prompt("Ingrese cantidad que desea convertir"));
	var C = (F-32)*5/9;
	var R = C;
	if (C<=42) {
		swal("Esta frio"+R);
	}else{
		swal("Esta que Arde"+R);
	}

}
G();