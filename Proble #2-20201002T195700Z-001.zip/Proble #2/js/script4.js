function Orden (){
	var n1 = parseInt(prompt("Ingrese primera cantidad"));
	var n2 = parseInt(prompt("Ingrese primera cantidad"));
	var n3 = parseInt(prompt("Ingrese primera cantidad"));
	if (parseInt(n1) > parseInt(n2) && parseInt(n1) > parseInt(n3)){
	if(parseInt(n2) > parseInt(n3)){
	alert(+n3)
	alert(+n2)
	alert(+n1)
	}else if (parseInt(n3) > parseInt(n2)){
	alert(n2)
	alert(n3)
	alert(n1)
	}
	}else if (parseInt(n2) > parseInt(n1) && parseInt(n2) > parseInt(n3)){
	if (parseInt(n1) > parseInt(n3)){
	alert(+n3)
	alert(+n1)
	alert(+n2)
	}else if (parseInt(n3) > parseInt(n1)){
	alert(+n1)
	alert(+n3)
	alert(+n2)
	}
	}else if (parseInt(n3) > parseInt(n2) && parseInt(n3) > parseInt(n1)){
	if (parseInt(n1) > parseInt(n2)){
	alert(+n2)
	alert(+n1)
	alert(+n3)
	}else if (parseInt(n2) > parseInt(n1)){
	alert(n1)
	alert(n2)
	alert(n3)
	}
	}
	}
Orden();