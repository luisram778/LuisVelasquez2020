$(document).ready(function(){
	$(".boton").click(function(){
		swal({
			text:"funciona de maravilla",
			icon:"success"
		})
	})
	$(".boton1").click(function(){
		swal({
			text:"pero no tengo su amor",
			icon:"success"
		})
    })
    $(".boton2").hover(function(){
    	swal("pero que importa");
    })
    $(".boton3").hover(function(){
    	swal("claro que me importa");
    })
    $(".boton4").click(function(){
		$(".imagen").toggle()
	})
})